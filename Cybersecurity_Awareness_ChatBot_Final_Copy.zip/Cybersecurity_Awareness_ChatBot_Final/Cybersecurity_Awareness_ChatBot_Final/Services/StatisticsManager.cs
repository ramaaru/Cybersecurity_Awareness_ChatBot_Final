﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final.Services
{
    public class StatisticsManager
    {
        private readonly ConversationManager _conversationManager;

        public StatisticsManager(ConversationManager conversationManager)
        {
            _conversationManager = conversationManager;
        }

        public class StatisticsData
        {
            public int TotalConversations { get; set; }
            public int PasswordQuestions { get; set; }
            public int PrivacyQuestions { get; set; }
            public int PhishingQuestions { get; set; }
            public int ScamQuestions { get; set; }
            public int HighRiskQuestions { get; set; }
            public string MostAskedTopic { get; set; } = "None";
            public string FavouriteTopic { get; set; } = "None";
            public Dictionary<string, int> TopicCounts { get; set; } = new();
        }

        public StatisticsData GetStatistics()
        {
            var conversations = _conversationManager.GetAllConversations();
            var data = new StatisticsData();

            data.TotalConversations = conversations.Count;

            // Count by topic
            data.PasswordQuestions = conversations.Count(c => c.Topic == "password");
            data.PrivacyQuestions = conversations.Count(c => c.Topic == "privacy");
            data.PhishingQuestions = conversations.Count(c => c.Topic == "phishing");
            data.ScamQuestions = conversations.Count(c => c.Topic == "scam");
            data.HighRiskQuestions = conversations.Count(c => c.RiskLevel == "High");

            // Topic counts
            data.TopicCounts = conversations
                .Where(c => !string.IsNullOrEmpty(c.Topic))
                .GroupBy(c => c.Topic)
                .ToDictionary(g => g.Key, g => g.Count());

            // Most asked topic
            if (data.TopicCounts.Any())
            {
                data.MostAskedTopic = data.TopicCounts
                    .OrderByDescending(kvp => kvp.Value)
                    .First().Key;
            }

            // Favourite topic (most common topic from user)
            var userTopics = conversations
                .Where(c => !string.IsNullOrEmpty(c.Topic))
                .GroupBy(c => c.Topic)
                .Select(g => new { Topic = g.Key, Count = g.Count() });

            if (userTopics.Any())
            {
                data.FavouriteTopic = userTopics
                    .OrderByDescending(x => x.Count)
                    .First().Topic;
            }

            return data;
        }

        public string GetMostFrequentTopic()
        {
            var stats = GetStatistics();
            return stats.MostAskedTopic;
        }

        public string GetFavouriteTopic()
        {
            var stats = GetStatistics();
            return stats.FavouriteTopic;
        }
    }
}
