﻿using Cybersecurity_Awareness_ChatBot_Final.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final.Services
{
    public class SearchManager
    {
        private readonly ConversationManager _conversationManager;

        public SearchManager(ConversationManager conversationManager)
        {
            _conversationManager = conversationManager;
        }

        public List<Conversation> Search(string query, string searchType = "All")
        {
            if (string.IsNullOrWhiteSpace(query))
            {
                return _conversationManager.GetAllConversations();
            }

            var conversations = _conversationManager.GetAllConversations();

            return searchType.ToLower() switch
            {
                "id" => conversations.Where(c => c.Id.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList(),
                "keyword" => conversations.Where(c =>
                    c.Question.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    c.Response.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList(),
                "topic" => conversations.Where(c =>
                    c.Topic.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList(),
                "date" => conversations.Where(c =>
                    c.Timestamp.ToString("yyyy-MM-dd").Contains(query)).ToList(),
                "risk" => conversations.Where(c =>
                    c.RiskLevel.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList(),
                _ => conversations.Where(c =>
                    c.Id.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    c.Question.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    c.Response.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    c.Topic.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    c.RiskLevel.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    c.Timestamp.ToString("yyyy-MM-dd HH:mm:ss").Contains(query)).ToList()
            };
        }
    }

    }