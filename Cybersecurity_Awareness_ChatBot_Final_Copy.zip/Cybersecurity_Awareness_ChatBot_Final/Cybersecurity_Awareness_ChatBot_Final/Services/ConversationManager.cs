﻿using Cybersecurity_Awareness_ChatBot_Final.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace Cybersecurity_Awareness_ChatBot_Final.Services
{
    public class ConversationManager
    {
        private readonly string _dataPath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory,
            "Data",
            "conversations.json"
        );

        private List<Conversation> _conversations = new();
        private int _nextNumber = 1;
        private readonly object _lock = new();

        public ConversationManager()
        {
            LoadConversations();
        }

        public void LoadConversations()
        {
            try
            {
                // Ensure Data directory exists
                var directory = Path.GetDirectoryName(_dataPath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                if (File.Exists(_dataPath))
                {
                    string json = File.ReadAllText(_dataPath);
                    _conversations = JsonSerializer.Deserialize<List<Conversation>>(json) ?? new List<Conversation>();

                    if (_conversations.Any())
                    {
                        _nextNumber = _conversations.Max(c => c.ConversationNumber) + 1;
                    }
                }
                else
                {
                    _conversations = new List<Conversation>();
                    _nextNumber = 1;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading conversations: {ex.Message}");
                _conversations = new List<Conversation>();
                _nextNumber = 1;
            }
        }

        public void SaveConversations()
        {
            lock (_lock)
            {
                try
                {
                    var directory = Path.GetDirectoryName(_dataPath);
                    if (!Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }

                    var options = new JsonSerializerOptions
                    {
                        WriteIndented = true
                    };

                    string json = JsonSerializer.Serialize(_conversations, options);
                    File.WriteAllText(_dataPath, json);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error saving conversations: {ex.Message}");
                }
            }
        }

        public Conversation AddConversation(string question, string response, string topic, string riskLevel = "Low")
        {
            lock (_lock)
            {
                var conversation = new Conversation
                {
                    Id = Guid.NewGuid().ToString(),
                    Question = question,
                    Response = response,
                    Topic = topic,
                    RiskLevel = riskLevel,
                    Timestamp = DateTime.Now,
                    ConversationNumber = _nextNumber++
                };

                _conversations.Add(conversation);
                SaveConversations();
                return conversation;
            }
        }

        public List<Conversation> GetAllConversations()
        {
            lock (_lock)
            {
                return _conversations.OrderByDescending(c => c.Timestamp).ToList();
            }
        }

        public Conversation GetConversationById(string id)
        {
            lock (_lock)
            {
                return _conversations.FirstOrDefault(c => c.Id == id);
            }
        }

        public bool DeleteConversation(string id)
        {
            lock (_lock)
            {
                var conversation = _conversations.FirstOrDefault(c => c.Id == id);
                if (conversation != null)
                {
                    _conversations.Remove(conversation);
                    SaveConversations();
                    return true;
                }
                return false;
            }
        }

        public void ClearAllConversations()
        {
            lock (_lock)
            {
                _conversations.Clear();
                _nextNumber = 1;
                SaveConversations();
            }
        }

        public int GetTotalCount()
        {
            lock (_lock)
            {
                return _conversations.Count;
            }
        }

        public List<Conversation> SearchByKeyword(string keyword)
        {
            lock (_lock)
            {
                if (string.IsNullOrWhiteSpace(keyword))
                {
                    return GetAllConversations();
                }

                keyword = keyword.ToLower();
                return _conversations
                    .Where(c => c.Question.ToLower().Contains(keyword) ||
                                c.Response.ToLower().Contains(keyword) ||
                                c.Topic.ToLower().Contains(keyword) ||
                                c.Id.ToLower().Contains(keyword) ||
                                c.RiskLevel.ToLower().Contains(keyword))
                    .OrderByDescending(c => c.Timestamp)
                    .ToList();
            }
        }

        public List<Conversation> SearchByDate(DateTime date)
        {
            lock (_lock)
            {
                return _conversations
                    .Where(c => c.Timestamp.Date == date.Date)
                    .OrderByDescending(c => c.Timestamp)
                    .ToList();
            }
        }

        public List<Conversation> SearchByTopic(string topic)
        {
            lock (_lock)
            {
                if (string.IsNullOrWhiteSpace(topic))
                {
                    return GetAllConversations();
                }

                return _conversations
                    .Where(c => c.Topic.Equals(topic, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(c => c.Timestamp)
                    .ToList();
            }
        }

        public void UpdateConversation(Conversation conversation)
        {
            lock (_lock)
            {
                var existing = _conversations.FirstOrDefault(c => c.Id == conversation.Id);
                if (existing != null)
                {
                    existing.Question = conversation.Question;
                    existing.Response = conversation.Response;
                    existing.Topic = conversation.Topic;
                    existing.RiskLevel = conversation.RiskLevel;
                    existing.Timestamp = conversation.Timestamp;
                    SaveConversations();
                }
            }
        }
    }
}
