﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final.Services
{
    public class ReportManager
    {
        private readonly ConversationManager _conversationManager;

        public ReportManager(ConversationManager conversationManager)
        {
            _conversationManager = conversationManager;
        }

        public string GenerateReport()
        {
            var conversations = _conversationManager.GetAllConversations();
            var sb = new StringBuilder();

            sb.AppendLine("==========================================");
            sb.AppendLine("     CYBER SECURITY CONVERSATION REPORT");
            sb.AppendLine("==========================================");
            sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"Total Conversations: {conversations.Count}");
            sb.AppendLine(new string('-', 42));

            if (!conversations.Any())
            {
                sb.AppendLine("\nNo conversations to report.");
                return sb.ToString();
            }

            foreach (var conv in conversations)
            {
                sb.AppendLine($"\nConversation #{conv.ConversationNumber}");
                sb.AppendLine($"ID: {conv.Id}");
                sb.AppendLine($"Date: {conv.Timestamp:yyyy-MM-dd HH:mm:ss}");
                sb.AppendLine($"Topic: {conv.Topic}");
                sb.AppendLine($"Risk Level: {conv.RiskLevel}");
                sb.AppendLine($"Question: {conv.Question}");
                sb.AppendLine($"Response: {conv.Response}");
                sb.AppendLine(new string('-', 42));
            }

            return sb.ToString();
        }

        public void ExportReport(string filePath = null)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                filePath = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "CyberSecurityReport.txt"
                );
            }

            var report = GenerateReport();
            File.WriteAllText(filePath, report);
        }
    }
}
