﻿using Cybersecurity_Awareness_ChatBot_Final.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final.Tests
{
    [TestClass]
    public class ChatBotTests
    {
        private ChatBot _bot;
        private ConversationManager _manager;

        [TestInitialize]
        public void Setup()
        {
            _manager = new ConversationManager();
            _bot = new ChatBot(_manager);
        }

        [TestMethod]
        public void Test_Greeting()
        {
            // Arrange
            var input = "Hello";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.IsTrue(response.Contains("Hello"));
            Assert.AreEqual("greeting", topic);
            Assert.AreEqual("Low", risk);
        }

        [TestMethod]
        public void Test_PasswordResponse()
        {
            // Arrange
            var input = "Tell me about passwords";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.AreEqual("password", topic);
            Assert.IsTrue(response.Contains("strong passwords") ||
                         response.Contains("password"));
        }

        [TestMethod]
        public void Test_PhishingResponse()
        {
            // Arrange
            var input = "How to avoid phishing";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.AreEqual("phishing", topic);
            Assert.IsTrue(response.Contains("phishing") ||
                         response.Contains("scammers"));
        }

        [TestMethod]
        public void Test_NameMemory()
        {
            // Arrange
            var input = "My name is John";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.IsTrue(response.Contains("John"));
            Assert.AreEqual("greeting", topic);
        }

        [TestMethod]
        public void Test_RiskDetection_High()
        {
            // Arrange
            var input = "Someone hacked my account";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.AreEqual("High", risk);
        }

        [TestMethod]
        public void Test_RiskDetection_Medium()
        {
            // Arrange
            var input = "I got a suspicious email";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.AreEqual("Medium", risk);
        }

        [TestMethod]
        public void Test_FavouriteTopic()
        {
            // Arrange
            var input = "I like passwords";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.IsTrue(response.Contains("passwords"));
        }

        [TestMethod]
        public void Test_FollowUp()
        {
            // Arrange
            var firstInput = "Tell me about phishing";
            var secondInput = "Tell me more";

            // Act
            _bot.GetResponse(firstInput, out string _, out string _);
            var response = _bot.GetResponse(secondInput, out string topic, out string risk);

            // Assert
            Assert.AreEqual("phishing", topic);
        }

        [TestMethod]
        public void Test_HelpResponse()
        {
            // Arrange
            var input = "Help";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.AreEqual("help", topic);
            Assert.IsTrue(response.Contains("help"));
        }

        [TestMethod]
        public void Test_Sentiment_Worried()
        {
            // Arrange
            var input = "I'm worried about security";

            // Act
            var response = _bot.GetResponse(input, out string topic, out string risk);

            // Assert
            Assert.AreEqual("sentiment", topic);
            Assert.IsTrue(response.Contains("worried") ||
                         response.Contains("understand"));
        }
    }
}
