﻿using Cybersecurity_Awareness_ChatBot_Final.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final.Tests
{
    [TestClass]
    public class ConversationTests
    {
        private ConversationManager _manager;
        private string _testPath;

        [TestInitialize]
        public void Setup()
        {
            _testPath = Path.Combine(Path.GetTempPath(), "test_conversations.json");
            _manager = new ConversationManager();
        }

        [TestCleanup]
        public void Cleanup()
        {
            if (File.Exists(_testPath))
            {
                File.Delete(_testPath);
            }
        }

        [TestMethod]
        public void Test_AddConversation()
        {
            // Arrange
            var question = "What is phishing?";
            var response = "Phishing is a cyber attack...";
            var topic = "phishing";
            var risk = "Low";

            // Act
            var conversation = _manager.AddConversation(question, response, topic, risk);

            // Assert
            Assert.IsNotNull(conversation);
            Assert.IsFalse(string.IsNullOrEmpty(conversation.Id));
            Assert.AreEqual(question, conversation.Question);
            Assert.AreEqual(response, conversation.Response);
            Assert.AreEqual(topic, conversation.Topic);
            Assert.AreEqual(risk, conversation.RiskLevel);
        }

        [TestMethod]
        public void Test_GetAllConversations()
        {
            // Arrange
            _manager.AddConversation("Q1", "A1", "password", "Low");
            _manager.AddConversation("Q2", "A2", "privacy", "Medium");

            // Act
            var conversations = _manager.GetAllConversations();

            // Assert
            Assert.AreEqual(2, conversations.Count);
        }

        [TestMethod]
        public void Test_DeleteConversation()
        {
            // Arrange
            var conv = _manager.AddConversation("Test", "Response", "general", "Low");

            // Act
            var result = _manager.DeleteConversation(conv.Id);

            // Assert
            Assert.IsTrue(result);
            var conversations = _manager.GetAllConversations();
            Assert.IsFalse(conversations.Any(c => c.Id == conv.Id));
        }

        [TestMethod]
        public void Test_ClearAllConversations()
        {
            // Arrange
            _manager.AddConversation("Q1", "A1", "password", "Low");
            _manager.AddConversation("Q2", "A2", "privacy", "Medium");

            // Act
            _manager.ClearAllConversations();
            var conversations = _manager.GetAllConversations();

            // Assert
            Assert.AreEqual(0, conversations.Count);
        }

        [TestMethod]
        public void Test_SearchByKeyword()
        {
            // Arrange
            _manager.AddConversation("Phishing email received", "Don't click", "phishing", "High");
            _manager.AddConversation("Password safety tips", "Use strong passwords", "password", "Low");

            // Act
            var results = _manager.SearchByKeyword("phishing");

            // Assert
            Assert.AreEqual(1, results.Count);
            Assert.IsTrue(results[0].Question.Contains("Phishing"));
        }

        [TestMethod]
        public void Test_SearchByTopic()
        {
            // Arrange
            _manager.AddConversation("Q1", "A1", "password", "Low");
            _manager.AddConversation("Q2", "A2", "privacy", "Medium");
            _manager.AddConversation("Q3", "A3", "password", "High");

            // Act
            var results = _manager.SearchByTopic("password");

            // Assert
            Assert.AreEqual(2, results.Count);
        }

        [TestMethod]
        public void Test_Statistics()
        {
            // Arrange
            _manager.AddConversation("Q1", "A1", "password", "Low");
            _manager.AddConversation("Q2", "A2", "privacy", "Medium");
            _manager.AddConversation("Q3", "A3", "phishing", "High");
            _manager.AddConversation("Q4", "A4", "password", "Low");

            var statsManager = new StatisticsManager(_manager);

            // Act
            var stats = statsManager.GetStatistics();

            // Assert
            Assert.AreEqual(4, stats.TotalConversations);
            Assert.AreEqual(2, stats.PasswordQuestions);
            Assert.AreEqual(1, stats.PrivacyQuestions);
            Assert.AreEqual(1, stats.PhishingQuestions);
            Assert.AreEqual(1, stats.HighRiskQuestions);
            Assert.AreEqual("password", stats.MostAskedTopic);
        }

        [TestMethod]
        public void Test_ReportGeneration()
        {
            // Arrange
            _manager.AddConversation("Test Q1", "Test A1", "password", "Low");
            _manager.AddConversation("Test Q2", "Test A2", "privacy", "Medium");

            var reportManager = new ReportManager(_manager);

            // Act
            var report = reportManager.GenerateReport();

            // Assert
            Assert.IsNotNull(report);
            Assert.IsTrue(report.Contains("CYBER SECURITY CONVERSATION REPORT"));
            Assert.IsTrue(report.Contains("Test Q1"));
            Assert.IsTrue(report.Contains("Test Q2"));
        }

        [TestMethod]
        public void Test_ExportReport()
        {
            // Arrange
            _manager.AddConversation("Export Test", "Response", "general", "Low");
            var reportManager = new ReportManager(_manager);
            var exportPath = Path.Combine(Path.GetTempPath(), "test_export.txt");

            try
            {
                // Act
                reportManager.ExportReport(exportPath);

                // Assert
                Assert.IsTrue(File.Exists(exportPath));
                var content = File.ReadAllText(exportPath);
                Assert.IsTrue(content.Contains("Export Test"));
            }
            finally
            {
                if (File.Exists(exportPath))
                {
                    File.Delete(exportPath);
                }
            }
        }

        [TestMethod]
        public void Test_ConversationNumbering()
        {
            // Arrange & Act
            var conv1 = _manager.AddConversation("Q1", "A1", "general", "Low");
            var conv2 = _manager.AddConversation("Q2", "A2", "general", "Low");
            var conv3 = _manager.AddConversation("Q3", "A3", "general", "Low");

            // Assert
            Assert.AreEqual(1, conv1.ConversationNumber);
            Assert.AreEqual(2, conv2.ConversationNumber);
            Assert.AreEqual(3, conv3.ConversationNumber);
        }

        [TestMethod]
        public void Test_GetConversationById()
        {
            // Arrange
            var conv = _manager.AddConversation("Test", "Response", "general", "Low");

            // Act
            var found = _manager.GetConversationById(conv.Id);

            // Assert
            Assert.IsNotNull(found);
            Assert.AreEqual(conv.Id, found.Id);
            Assert.AreEqual("Test", found.Question);
        }
    }
}
