﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Cybersecurity_Awareness_ChatBot_Final.Services;
using Cybersecurity_Awareness_ChatBot_Final.Windows;
using Microsoft.Win32;

namespace Cybersecurity_Awareness_ChatBot_Final
{
    public partial class MainWindow : Window
    {
        private ChatBot _bot;
        private ConversationManager _conversationManager;
        private StatisticsManager _statisticsManager;
        private ReportManager _reportManager;
        private SearchManager _searchManager;

        public MainWindow()
        {
            InitializeComponent(); 

            // Initialize all services
            _conversationManager = new ConversationManager();
            _statisticsManager = new StatisticsManager(_conversationManager);
            _reportManager = new ReportManager(_conversationManager);
            _searchManager = new SearchManager(_conversationManager);
            _bot = new ChatBot(_conversationManager);

            // Play voice greeting
            VoiceGreeting.PlayGreeting();

            // Show daily tip
            DailyTipText.Text = _bot.GetDailyTip();

            // Update conversation counter
            UpdateConversationCounter();

            // Welcome message
            ChatArea.AppendText(
                "═══════════════════════════════════════════════════════════\n" +
                "        🛡️ CYBER SECURITY AWARENESS BOT v3.0 🛡️\n" +
                "═══════════════════════════════════════════════════════════\n\n" +
                "BOT: Welcome to the Cyber Security Awareness System!\n" +
                "BOT: I can help you with:\n" +
                "BOT:   • Password safety\n" +
                "BOT:   • Phishing protection\n" +
                "BOT:   • Privacy tips\n" +
                "BOT:   • Online scams\n" +
                "BOT:   • Malware, VPNs, encryption, and more\n\n" +
                "BOT: Click one of the topic buttons on the left,\n" +
                "BOT: or type your own question below.\n\n"
            );

            ChatArea.ScrollToEnd();
            UserInput.Focus();
        }

        private void UpdateConversationCounter()
        {
            var count = _conversationManager.GetTotalCount() + 1;
            ConversationCounter.Text = $"Conversation #{count}";
        }

        private void SendMessage()
        {
            string userMessage = UserInput.Text.Trim();

            if (string.IsNullOrWhiteSpace(userMessage))
            {
                return;
            }

            // Show user message
            ChatArea.AppendText($"YOU: {userMessage}\n");

            // Get bot response
            string response = _bot.GetResponse(userMessage, out string topic, out string riskLevel);

            // Show bot response
            ChatArea.AppendText($"BOT: {response}\n");

            // Show risk level
            if (riskLevel == "High")
            {
                ChatArea.AppendText($"⚠️ RISK LEVEL: {riskLevel} - Please review your security practices.\n");
            }
            else if (riskLevel == "Medium")
            {
                ChatArea.AppendText($"⚡ RISK LEVEL: {riskLevel} - Consider taking precautions.\n");
            }

            ChatArea.AppendText("\n");

            // Save conversation
            _conversationManager.AddConversation(userMessage, response, topic, riskLevel);

            // Update counter
            UpdateConversationCounter();

            ChatArea.ScrollToEnd();
            UserInput.Clear();
            UserInput.Focus();
        }

        // ==================== BUTTON HANDLERS ====================

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private void UserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                SendMessage();
            }
        }

        // Topic Buttons
        private void PasswordButton_Click(object sender, RoutedEventArgs e)
        {
            UserInput.Text = "Tell me about password safety";
            SendMessage();
        }

        private void PhishingButton_Click(object sender, RoutedEventArgs e)
        {
            UserInput.Text = "Tell me about phishing protection";
            SendMessage();
        }

        private void PrivacyButton_Click(object sender, RoutedEventArgs e)
        {
            UserInput.Text = "Tell me about online privacy";
            SendMessage();
        }

        private void ScamButton_Click(object sender, RoutedEventArgs e)
        {
            UserInput.Text = "Tell me about online scams";
            SendMessage();
        }

        // Feature Buttons
        private void HistoryButton_Click(object sender, RoutedEventArgs e)
        {
            var window = new HistoryWindow(_conversationManager) { Owner = this };
            window.ShowDialog();
        }

        private void StatisticsButton_Click(object sender, RoutedEventArgs e)
        {
            var window = new StatisticsWindow(_statisticsManager) { Owner = this };
            window.ShowDialog();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            var window = new SearchWindow(_searchManager) { Owner = this };
            window.ShowDialog();
        }

        private void ReportButton_Click(object sender, RoutedEventArgs e)
        {
            var report = _reportManager.GenerateReport();

            ChatArea.AppendText(
                "═══════════════════════════════════════════════════════════\n" +
                "📄 CONVERSATION REPORT\n" +
                "═══════════════════════════════════════════════════════════\n"
            );
            ChatArea.AppendText(report);
            ChatArea.AppendText("\n");
            ChatArea.ScrollToEnd();

            MessageBox.Show("Report generated and displayed in chat.", "Report Generated",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            var saveDialog = new SaveFileDialog
            {
                Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                DefaultExt = "txt",
                FileName = "CyberSecurityReport.txt"
            };

            if (saveDialog.ShowDialog() == true)
            {
                _reportManager.ExportReport(saveDialog.FileName);
                MessageBox.Show($"Report exported to:\n{saveDialog.FileName}", "Export Successful",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Enter Conversation ID to delete:", "Delete Conversation");
            if (dialog.ShowDialog() == true)
            {
                string id = dialog.InputText;
                if (!string.IsNullOrWhiteSpace(id))
                {
                    if (_conversationManager.DeleteConversation(id))
                    {
                        MessageBox.Show($"Conversation {id} deleted successfully.", "Deleted",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        UpdateConversationCounter();
                    }
                    else
                    {
                        MessageBox.Show($"Conversation {id} not found.", "Not Found",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
        }

        private void ClearHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to delete ALL conversations?\n\nThis action cannot be undone.",
                "Clear All History",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                _conversationManager.ClearAllConversations();
                UpdateConversationCounter();
                MessageBox.Show("All conversations cleared.", "Cleared",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            ChatArea.AppendText(
                "═══════════════════════════════════════════════════════════\n" +
                "❓ HELP\n" +
                "═══════════════════════════════════════════════════════════\n\n" +
                "HOW TO USE THIS BOT:\n" +
                "• Type any cybersecurity question in the input box\n" +
                "• Or click topic buttons on the left panel\n" +
                "• The bot remembers your name and favourite topics\n" +
                "\n" +
                "FEATURES:\n" +
                "• 📜 History - View all conversations\n" +
                "• 📊 Statistics - See usage analytics\n" +
                "• 🔍 Search - Find conversations by ID, keyword, or topic\n" +
                "• 📄 Generate Report - Create a conversation summary\n" +
                "• 💾 Export Report - Save report to file\n" +
                "• 🗑️ Delete by ID - Remove specific conversations\n" +
                "• 🧹 Clear All History - Delete all conversations\n" +
                "\n" +
                "TIPS:\n" +
                "• Try saying 'My name is [name]' to introduce yourself\n" +
                "• Say 'I like [topic]' to set your favourite topic\n" +
                "• Use 'Tell me more' for follow-up information\n" +
                "• Risk levels help you identify urgent security concerns\n" +
                "═══════════════════════════════════════════════════════════\n\n"
            );
            ChatArea.ScrollToEnd();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            _conversationManager.SaveConversations();
        }
    }
}