﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Media;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final
{
    public static class VoiceGreeting
    {
        /// <summary>
        /// Plays the greeting.wav file from the Assets folder.
        /// </summary>
        public static void PlayGreeting()
        {
            try
            {
                // Build the path to the Assets folder
                string path = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "Assets",
                    "greeting.wav"
                );

                // Check if the file exists
                if (File.Exists(path))
                {
                    // Play the audio asynchronously
                    using (SoundPlayer player = new SoundPlayer(path))
                    {
                        // Play asynchronously so the UI thread isn't blocked at startup
                        player.Play();
                    }
                }
                else
                {
                    // Log that the file was not found (silent fail)
                    System.Diagnostics.Debug.WriteLine($"greeting.wav not found at: {path}");
                }
            }
            catch (Exception ex)
            {
                // Swallow exceptions to avoid interfering with application startup
                System.Diagnostics.Debug.WriteLine($"Error playing greeting: {ex.Message}");
            }
        }

        /// <summary>
        /// Plays the greeting synchronously (waits for completion).
        /// Use this if you want to ensure the greeting plays fully before continuing.
        /// </summary>
        public static void PlayGreetingSync()
        {
            try
            {
                string path = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "Assets",
                    "greeting.wav"
                );

                if (File.Exists(path))
                {
                    using (SoundPlayer player = new SoundPlayer(path))
                    {
                        // Play synchronously - waits for audio to finish
                        player.PlaySync();
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error playing greeting: {ex.Message}");
            }
        }

        /// <summary>
        /// Plays the greeting in a loop (useful for testing).
        /// </summary>
        public static void PlayGreetingLoop()
        {
            try
            {
                string path = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "Assets",
                    "greeting.wav"
                );

                if (File.Exists(path))
                {
                    using (SoundPlayer player = new SoundPlayer(path))
                    {
                        // Play in a loop
                        player.PlayLooping();
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error playing greeting: {ex.Message}");
            }
        }

        /// <summary>
        /// Stops any currently playing greeting.
        /// </summary>
        public static void StopGreeting()
        {
            try
            {
                // SoundPlayer doesn't have a global stop method,
                // but we can create a new player and stop it
                string path = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "Assets",
                    "greeting.wav"
                );

                if (File.Exists(path))
                {
                    using (SoundPlayer player = new SoundPlayer(path))
                    {
                        player.Stop();
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error stopping greeting: {ex.Message}");
            }
        }

        /// <summary>
        /// Checks if the greeting.wav file exists and is valid.
        /// </summary>
        public static bool GreetingFileExists()
        {
            try
            {
                string path = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "Assets",
                    "greeting.wav"
                );

                return File.Exists(path);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the full path to the greeting.wav file.
        /// </summary>
        public static string GetGreetingPath()
        {
            return Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "Assets",
                "greeting.wav"
            );
        }

        /// <summary>
        /// Plays the greeting with fallback to default Windows sound if file missing.
        /// </summary>
        public static void PlayGreetingWithFallback()
        {
            try
            {
                string path = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "Assets",
                    "greeting.wav"
                );

                if (File.Exists(path))
                {
                    using (SoundPlayer player = new SoundPlayer(path))
                    {
                        player.Play();
                    }
                }
                else
                {
                    // Fallback to system beep
                    System.Media.SystemSounds.Beep.Play();
                    System.Diagnostics.Debug.WriteLine("greeting.wav not found - using system beep as fallback");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error playing greeting: {ex.Message}");
            }
        }
    }
}
