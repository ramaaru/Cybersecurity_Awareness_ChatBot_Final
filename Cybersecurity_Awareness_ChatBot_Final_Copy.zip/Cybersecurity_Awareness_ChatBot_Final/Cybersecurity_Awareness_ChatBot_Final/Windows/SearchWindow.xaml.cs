﻿using Cybersecurity_Awareness_ChatBot_Final.Services;
using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cybersecurity_Awareness_ChatBot_Final.Windows
{
    public partial class SearchWindow : Window
    {
        private readonly SearchManager _searchManager;

        public SearchWindow(SearchManager searchManager)
        {
            InitializeComponent();
            _searchManager = searchManager;
            SearchBox.Focus();
        }

        private void PerformSearch()
        {
            string query = SearchBox.Text.Trim();
            string searchType = (SearchTypeCombo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "All";

            var results = _searchManager.Search(query, searchType);
            var sb = new StringBuilder();

            sb.AppendLine("====================================================");
            sb.AppendLine($"   SEARCH RESULTS: {results.Count} found");
            sb.AppendLine($"   Query: {(string.IsNullOrEmpty(query) ? "All" : query)}");
            sb.AppendLine($"   Type: {searchType}");
            sb.AppendLine("====================================================\n");

            if (!results.Any())
            {
                sb.AppendLine("No conversations found matching your search.");
            }
            else
            {
                foreach (var conv in results)
                {
                    sb.AppendLine($"Conversation #{conv.ConversationNumber}");
                    sb.AppendLine($"ID: {conv.Id}");
                    sb.AppendLine($"Date: {conv.Timestamp:yyyy-MM-dd HH:mm:ss}");
                    sb.AppendLine($"Topic: {conv.Topic}");
                    sb.AppendLine($"Risk: {conv.RiskLevel}");
                    sb.AppendLine($"Question: {conv.Question}");
                    sb.AppendLine($"Response: {conv.Response}");
                    sb.AppendLine(new string('-', 50));
                }
            }

            SearchResults.Text = sb.ToString();
            SearchResults.ScrollToEnd();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            PerformSearch();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                PerformSearch();
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Clear();
            SearchResults.Clear();
            SearchBox.Focus();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

}