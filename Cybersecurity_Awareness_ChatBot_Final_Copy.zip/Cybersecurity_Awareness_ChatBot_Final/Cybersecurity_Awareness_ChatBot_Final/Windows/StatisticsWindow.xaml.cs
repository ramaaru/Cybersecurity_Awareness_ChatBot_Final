﻿using Cybersecurity_Awareness_ChatBot_Final.Services;
using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cybersecurity_Awareness_ChatBot_Final.Windows
{
    public partial class StatisticsWindow : Window
    {
        private readonly StatisticsManager _statisticsManager;

        public StatisticsWindow(StatisticsManager statisticsManager)
        {
            InitializeComponent();
            _statisticsManager = statisticsManager;
            LoadStatistics();
        }

        private void LoadStatistics()
        {
            var stats = _statisticsManager.GetStatistics();
            var sb = new StringBuilder();

            sb.AppendLine("╔══════════════════════════════════════════════════════╗");
            sb.AppendLine("║              STATISTICS DASHBOARD                   ║");
            sb.AppendLine("╚══════════════════════════════════════════════════════╝");
            sb.AppendLine();

            sb.AppendLine($"📊 Total Conversations:        {stats.TotalConversations}");
            sb.AppendLine();

            sb.AppendLine("📌 TOPIC BREAKDOWN:");
            sb.AppendLine($"   • Password Questions:      {stats.PasswordQuestions}");
            sb.AppendLine($"   • Privacy Questions:       {stats.PrivacyQuestions}");
            sb.AppendLine($"   • Phishing Questions:      {stats.PhishingQuestions}");
            sb.AppendLine($"   • Scam Questions:          {stats.ScamQuestions}");
            sb.AppendLine();

            sb.AppendLine($"⚠️  High Risk Questions:      {stats.HighRiskQuestions}");
            sb.AppendLine();

            sb.AppendLine($"🏆 Most Asked Topic:         {stats.MostAskedTopic}");
            sb.AppendLine($"⭐ Favourite Topic:          {stats.FavouriteTopic}");
            sb.AppendLine();

            sb.AppendLine("📋 ALL TOPICS:");
            if (stats.TopicCounts.Any())
            {
                foreach (var topic in stats.TopicCounts.OrderByDescending(x => x.Value))
                {
                    sb.AppendLine($"   • {topic.Key}: {topic.Value} conversations");
                }
            }
            else
            {
                sb.AppendLine("   No topics recorded yet.");
            }

            sb.AppendLine();
            sb.AppendLine($"📅 Last Updated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");

            StatsArea.Text = sb.ToString();
            StatsArea.ScrollToEnd();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadStatistics();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}