﻿using Cybersecurity_Awareness_ChatBot_Final.Services;
using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cybersecurity_Awareness_ChatBot_Final.Windows
{

    public partial class HistoryWindow : Window
    {
        private readonly ConversationManager _conversationManager;

        public HistoryWindow(ConversationManager conversationManager)
        {
            InitializeComponent();
            _conversationManager = conversationManager;
            LoadHistory();
        }

        private void LoadHistory()
        {
            var conversations = _conversationManager.GetAllConversations();
            var sb = new StringBuilder();

            if (!conversations.Any())
            {
                sb.AppendLine("====================================================");
                sb.AppendLine("              NO CONVERSATIONS FOUND");
                sb.AppendLine("====================================================");
                sb.AppendLine("\nStart a conversation to begin tracking your history.");
                HistoryArea.Text = sb.ToString();
                return;
            }

            foreach (var conv in conversations)
            {
                sb.AppendLine("====================================================");
                sb.AppendLine($"Conversation #{conv.ConversationNumber}");
                sb.AppendLine($"ID: {conv.Id}");
                sb.AppendLine($"Date: {conv.Timestamp:yyyy-MM-dd HH:mm:ss}");
                sb.AppendLine($"Topic: {conv.Topic}");
                sb.AppendLine($"Risk Level: {conv.RiskLevel}");
                sb.AppendLine("----------------------------------------------------");
                sb.AppendLine($"Question: {conv.Question}");
                sb.AppendLine($"Response: {conv.Response}");
                sb.AppendLine("====================================================\n");
            }

            sb.AppendLine($"\nTotal Conversations: {conversations.Count}");

            HistoryArea.Text = sb.ToString();
            HistoryArea.ScrollToEnd();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadHistory();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}