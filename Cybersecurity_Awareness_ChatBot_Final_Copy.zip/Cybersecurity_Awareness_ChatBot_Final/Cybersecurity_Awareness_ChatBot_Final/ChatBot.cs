﻿using Cybersecurity_Awareness_ChatBot_Final.Services;
using Cybersecurity_Awareness_ChatBot_Final.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final
{
    public class ChatBot
    {
        private readonly Dictionary<string, List<string>> _keywordResponses;
        private readonly ConversationManager _conversationManager;
        private readonly StatisticsManager _statisticsManager;

        // Enhanced memory
        private string _userName = "";
        private string _favouriteTopic = "";
        private string _lastTopic = "";
        private int _conversationCount = 0;
        private readonly List<string> _discussedTopics = new();

        // Daily tips
        private static readonly string[] _dailyTips = {
            "Never reuse passwords across different accounts.",
            "Enable two-factor authentication whenever possible.",
            "Be cautious of emails asking for personal information.",
            "Use a password manager to generate and store strong passwords.",
            "Keep your software and operating system updated.",
            "Regularly check your bank statements for unauthorized transactions.",
            "Use a VPN when connecting to public Wi-Fi.",
            "Think before you click on suspicious links.",
            "Backup your important data regularly.",
            "Use unique, complex passwords for each account.",
            "Monitor your credit reports annually.",
            "Be careful what you share on social media.",
            "Use secure, encrypted messaging apps.",
            "Enable firewall protection on your devices.",
            "Be wary of phone calls asking for personal information."
        };

        public ChatBot(ConversationManager conversationManager)
        {
            _conversationManager = conversationManager;
            _statisticsManager = new StatisticsManager(conversationManager);

            // Load stats for better memory
            var stats = _statisticsManager.GetStatistics();
            _conversationCount = stats.TotalConversations;

            _keywordResponses = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            {
                // Password related
                ["password"] = new List<string>
                {
                    "Use strong passwords with uppercase letters, numbers, and symbols.",
                    "Avoid using birthdays or names in your passwords.",
                    "Use a different password for every account.",
                    "Enable two-factor authentication for extra security.",
                    "Consider using a password manager for secure storage."
                },
                ["passwords"] = new List<string>
                {
                    "Use strong passwords with uppercase letters, numbers, and symbols.",
                    "Avoid using birthdays or names in your passwords.",
                    "Use a different password for every account.",
                    "Enable two-factor authentication for extra security.",
                    "Consider using a password manager for secure storage."
                },
                ["passcode"] = new List<string>
                {
                    "Use a strong passcode that's not easily guessable.",
                    "Avoid common passcodes like 1234 or 0000.",
                    "Enable biometric authentication when available."
                },
                ["credential"] = new List<string>
                {
                    "Always store credentials securely.",
                    "Never share your login credentials with anyone.",
                    "Use unique credentials for each service."
                },
                ["login"] = new List<string>
                {
                    "Always log out of accounts when using public computers.",
                    "Use secure login methods with encryption.",
                    "Monitor your login activity for suspicious access."
                },

                // Phishing related
                ["phishing"] = new List<string>
                {
                    "Never click suspicious email links from unknown senders.",
                    "Scammers often pretend to be trusted companies.",
                    "Always verify email addresses before opening attachments.",
                    "Be wary of urgent payment requests via email.",
                    "Report phishing attempts to your IT department."
                },
                ["malware"] = new List<string>
                {
                    "Keep your antivirus software up to date.",
                    "Don't download files from untrusted sources.",
                    "Be careful with email attachments from unknown senders.",
                    "Use a firewall to block unauthorized access."
                },
                ["ransomware"] = new List<string>
                {
                    "Regularly backup your important files.",
                    "Don't pay ransoms - report to authorities instead.",
                    "Use robust security software to detect ransomware.",
                    "Be suspicious of unexpected file encryption."
                },

                // Privacy related
                ["privacy"] = new List<string>
                {
                    "Review your social media privacy settings regularly.",
                    "Avoid sharing personal information on unsafe websites.",
                    "Enable two-factor authentication to improve privacy.",
                    "Use private browsing mode for sensitive activities.",
                    "Limit the information you share online."
                },
                ["vpn"] = new List<string>
                {
                    "Use a VPN to encrypt your internet connection.",
                    "VPNs protect your privacy on public Wi-Fi.",
                    "Choose a reputable VPN service with no-log policy."
                },
                ["encryption"] = new List<string>
                {
                    "Use encryption to protect sensitive data.",
                    "Enable device encryption on your devices.",
                    "Use end-to-end encrypted messaging apps."
                },

                // Scam related
                ["scam"] = new List<string>
                {
                    "Never send money to strangers online.",
                    "Scammers often create fake urgency to pressure victims.",
                    "Be careful of fake competitions and giveaways.",
                    "Verify companies before making payments online.",
                    "Trust your instincts - if it seems too good to be true, it is."
                },
                ["social engineering"] = new List<string>
                {
                    "Be careful of manipulative tactics used by scammers.",
                    "Never share sensitive information over the phone.",
                    "Verify the identity of people requesting information.",
                    "Trust but verify - always confirm suspicious requests."
                },

                // Firewall related
                ["firewall"] = new List<string>
                {
                    "Enable your firewall to monitor network traffic.",
                    "Firewalls block unauthorized access to your system.",
                    "Configure your firewall to allow only trusted connections."
                },

                // Antivirus related
                ["antivirus"] = new List<string>
                {
                    "Install reputable antivirus software on all devices.",
                    "Keep your antivirus definitions updated.",
                    "Run regular system scans to detect threats.",
                    "Consider using multiple security layers for protection."
                }
            };
        }

        public string GetResponse(string input, out string topic, out string riskLevel)
        {
            topic = "general";
            riskLevel = "Low";

            if (string.IsNullOrWhiteSpace(input))
            {
                topic = "error";
                return "Please type a message.";
            }

            input = input.Trim();
            string lowerInput = input.ToLower();

            // === RISK DETECTION ===
            riskLevel = DetectRisk(lowerInput);

            // === GREETINGS ===
            if (lowerInput.Contains("hello") || lowerInput.Contains("hi") || lowerInput.Contains("hey"))
            {
                string greeting = string.IsNullOrEmpty(_userName)
                    ? "Hello! How can I help you stay safe online today?"
                    : $"Hello {_userName}! How can I help you stay safe online today?";
                topic = "greeting";
                return greeting;
            }

            // === HELP ===
            if (lowerInput.Contains("help") || lowerInput.Contains("what can you do"))
            {
                topic = "help";
                return "I can help you with:\n• Password safety\n• Phishing protection\n• Privacy tips\n• Online scams\n• Malware prevention\n• VPN and encryption\n• And more! Just ask me about any cybersecurity topic.";
            }

            // === NAME MEMORY ===
            if (lowerInput.Contains("my name is") || lowerInput.Contains("i am ") || lowerInput.Contains("call me "))
            {
                var patterns = new[] { "my name is ", "i am ", "call me " };
                foreach (var pattern in patterns)
                {
                    if (lowerInput.Contains(pattern))
                    {
                        int index = lowerInput.IndexOf(pattern) + pattern.Length;
                        _userName = input.Substring(index).Trim();
                        topic = "greeting";
                        return $"Nice to meet you, {_userName}! I'll remember your name for our conversation.";
                    }
                }
            }

            // === FAVOURITE TOPIC ===
            if (lowerInput.Contains("i like ") || lowerInput.Contains("i love "))
            {
                string prefix = lowerInput.Contains("i like ") ? "i like " : "i love ";
                int index = lowerInput.IndexOf(prefix) + prefix.Length;
                _favouriteTopic = lowerInput.Substring(index).Trim();
                topic = "preference";
                return $"Great! I'll remember that you're interested in {_favouriteTopic}. What would you like to learn about?";
            }

            // === SENTIMENT DETECTION ===
            if (lowerInput.Contains("worried") || lowerInput.Contains("scared") || lowerInput.Contains("anxious"))
            {
                topic = "sentiment";
                return "It's understandable to feel worried about cybersecurity threats. The good news is there are many steps you can take to protect yourself. What specific concern do you have?";
            }

            if (lowerInput.Contains("frustrated") || lowerInput.Contains("confused") || lowerInput.Contains("tired"))
            {
                topic = "sentiment";
                return "I understand cybersecurity can feel overwhelming. Let's take it step by step - what area would you like to learn about first?";
            }

            if (lowerInput.Contains("curious") || lowerInput.Contains("interested") || lowerInput.Contains("want to learn"))
            {
                topic = "sentiment";
                return "That's excellent! Curiosity is the first step to better cybersecurity. What would you like to know more about?";
            }

            // === FOLLOW-UP ===
            if (lowerInput.Contains("tell me more") ||
                lowerInput.Contains("another tip") ||
                lowerInput.Contains("explain more") ||
                lowerInput.Contains("more info") ||
                lowerInput.Contains("details"))
            {
                if (!string.IsNullOrEmpty(_lastTopic))
                {
                    return GetRandomResponse(_lastTopic, out string followUpTopic);
                }
                else
                {
                    topic = "error";
                    return "Please ask about a cybersecurity topic first, then I can give you more details.";
                }
            }

            // === KEYWORD RECOGNITION ===
            foreach (var keyword in _keywordResponses.Keys)
            {
                if (lowerInput.Contains(keyword))
                {
                    topic = keyword;
                    _lastTopic = keyword;
                    _discussedTopics.Add(keyword);

                    string response = GetRandomResponse(keyword, out string responseTopic);

                    // Personalized name response
                    if (!string.IsNullOrEmpty(_userName))
                    {
                        response = $"{_userName}, {response}";
                    }

                    // Personalized favourite topic response
                    if (!string.IsNullOrEmpty(_favouriteTopic) &&
                        lowerInput.Contains(_favouriteTopic))
                    {
                        response += $" Since you're interested in {_favouriteTopic}, I'd recommend exploring this topic further.";
                    }

                    // Contextual follow-up
                    if (_discussedTopics.Count > 1)
                    {
                        var distinctTopics = _discussedTopics.Distinct().ToList();
                        if (distinctTopics.Count > 1)
                        {
                            response += $" You've also asked about {string.Join(", ", distinctTopics.Take(3))}. Would you like to learn more about any of these?";
                        }
                    }

                    return response;
                }
            }

            // === DEFAULT ===
            topic = "general";
            return "I'm not sure I understand. I can help with passwords, phishing, privacy, scams, malware, VPNs, encryption, and more. What would you like to learn about?";
        }

        private string GetRandomResponse(string keyword, out string topic)
        {
            topic = keyword;
            var random = new Random();

            if (_keywordResponses.TryGetValue(keyword, out var responses))
            {
                int index = random.Next(responses.Count);
                return responses[index];
            }

            // Try case-insensitive match
            foreach (var kvp in _keywordResponses)
            {
                if (kvp.Key.Equals(keyword, StringComparison.OrdinalIgnoreCase))
                {
                    int index = random.Next(kvp.Value.Count);
                    return kvp.Value[index];
                }
            }

            topic = "general";
            return "I'm not sure about that topic. Could you ask about something else?";
        }

        private string DetectRisk(string input)
        {
            // High risk indicators
            string[] highRiskIndicators = {
                "hacked", "breach", "stolen", "compromised", "identity theft",
                "fraud", "unauthorized", "suspicious activity", "virus", "malware",
                "ransomware", "scam", "phishing attempt", "data leak", "security breach"
            };

            // Medium risk indicators
            string[] mediumRiskIndicators = {
                "suspicious", "unusual", "password reset", "unexpected", "strange",
                "unknown sender", "link", "attachment", "urgent payment", "bank details"
            };

            foreach (var indicator in highRiskIndicators)
            {
                if (input.Contains(indicator))
                {
                    return "High";
                }
            }

            foreach (var indicator in mediumRiskIndicators)
            {
                if (input.Contains(indicator))
                {
                    return "Medium";
                }
            }

            return "Low";
        }

        public string GetDailyTip()
        {
            var random = new Random();
            int index = random.Next(_dailyTips.Length);
            return $"💡 Cyber Tip of the Day: {_dailyTips[index]}";
        }

        public string GetConversationCounter()
        {
            _conversationCount = _conversationManager.GetTotalCount() + 1;
            return $"Conversation #{_conversationCount}";
        }

        public string GetUserName()
        {
            return _userName;
        }

        public void SetUserName(string name)
        {
            if (!string.IsNullOrWhiteSpace(name))
            {
                _userName = name.Trim();
            }
        }

        public string GetFavouriteTopic()
        {
            return _favouriteTopic;
        }

        public void SetFavouriteTopic(string topic)
        {
            if (!string.IsNullOrWhiteSpace(topic))
            {
                _favouriteTopic = topic.Trim();
            }
        }
    }
}
