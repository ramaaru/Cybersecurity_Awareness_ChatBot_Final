﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cybersecurity_Awareness_ChatBot_Final.Models
{
    public class Conversation
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Question { get; set; } = string.Empty;
        public string Response { get; set; } = string.Empty;
        public string Topic { get; set; } = string.Empty;
        public string RiskLevel { get; set; } = "Low";
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public int ConversationNumber { get; set; }
    }
}
